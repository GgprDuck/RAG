import { IChatLlmPort } from 'src/rag/domain/ports/chat-llm.port';
import type { TextVectorSearchMode as SearchMode } from 'src/rag/domain/ports/text-vector-search.port';

export type QueryType = 'entity' | 'factual' | 'wide';

export interface QueryClassification {
  type: QueryType;

  confidence: number;

  params: FineTuningParams;
}

export interface FineTuningParams {
  limit: number;

  scoreThreshold: number;

  searchMode: SearchMode | 'entity';

  useHybridSearch: boolean;

  useQueryTransformation: boolean;

  useReranking: boolean;

  rerankStrategy: 'cross_encoder' | 'llm_based' | 'none' | 'hybrid';

  useContextualCompression: boolean;

  useParentExpansion: boolean;

  useKnowledgeGraph: boolean;

  useConversationMemory: boolean;

  useCitationTracking: boolean;

  temperature: number;

  topP: number | undefined;

  topK: number | undefined;

  maxTokens: number;

  repeatPenalty: number | undefined;

  seed: number | undefined;
}

const PROFILE_BY_TYPE: Record<QueryType, FineTuningParams> = {
  entity: {
    limit:                    16,
    scoreThreshold:           0.6,
    searchMode:               'entity',
    useHybridSearch:          true,
    useQueryTransformation:   true,
    useReranking:             true,
    rerankStrategy:           'hybrid',
    useContextualCompression: true,
    useParentExpansion:       true,
    useKnowledgeGraph:        true,
    useConversationMemory:    false,
    useCitationTracking:      true,
    temperature:              0,
    topP:                     1,
    topK:                     5,
    maxTokens:                10000,
    repeatPenalty:            undefined,
    seed:                     undefined,
  },
  factual: {
    limit:                    15,
    scoreThreshold:           0.85,
    searchMode:               'balanced',
    useHybridSearch:          true,
    useQueryTransformation:   true,
    useReranking:             true,
    rerankStrategy:           'cross_encoder',
    useContextualCompression: true,
    useParentExpansion:       true,
    useKnowledgeGraph:        false,
    useConversationMemory:    false,
    useCitationTracking:      true,
    temperature:              0.3,
    topP:                     0.85,
    topK:                     20,
    maxTokens:                3200,
    repeatPenalty:            1.1,
    seed:                     undefined,
  },
  wide: {
    limit:                    12,
    scoreThreshold:           0.72,
    searchMode:               'wide',
    useHybridSearch:          true,
    useQueryTransformation:   true,
    useReranking:             true,
    rerankStrategy:           'hybrid',
    useContextualCompression: true,
    useParentExpansion:       true,
    useKnowledgeGraph:        true,
    useConversationMemory:    false,
    useCitationTracking:      true,
    temperature:              0.3,
    topP:                     1,
    topK:                     2,
    maxTokens:                7200,
    repeatPenalty:            1.2,
    seed:                     undefined,
  },
};

function preGuardClassify(query: string): QueryType | null {
  const raw = query.trim();
  const q = raw.toLowerCase().replace(/[?!.,;:]/g, '').trim();

  const looksLikePersonSubject = (subjectRaw: string): boolean => {
    const subject = subjectRaw.trim();
    if (!subject || /\d/.test(subject)) return false;
    const tokens = subject
      .split(/\s+/)
      .map((t) => t.replace(/^[^\p{L}]+|[^\p{L}'-]+$/gu, ''))
      .filter(Boolean);
    if (tokens.length === 0 || tokens.length > 3) return false;

    const nonPersonWords = new Set([
      'onix', 'company', 'компанія', 'department', 'департамент', 'відділ',
      'team', 'команда', 'product', 'tool', 'academy', 'platform', 'system',
      'hr', 'qa', 'node', 'react',
    ]);
    if (tokens.some((t) => nonPersonWords.has(t.toLowerCase()))) return false;

    const capitalizedCount = tokens.filter((t) => /^[\p{Lu}][\p{L}'-]*$/u.test(t)).length;
    return capitalizedCount >= 1;
  };

  const isNameOriginQuery =
    /\b(why|what|what is)\b.{0,30}\b(name|called|named|mean|origin|history|founded|create)\b/i.test(q) ||
    /\b(name|назв).{0,20}\b(company|компан|brand|бренд)\b/i.test(q) ||
    /\b(company|компан).{0,20}\b(name|назв|called|mean)\b/i.test(q);

  if (isNameOriginQuery) return 'factual';

  const isWhatIs =
    /^(what is|what are|що таке|що це|що таке|що є)\s+\S+(\s+\S+)?$/.test(q);
  if (isWhatIs) return 'wide';

  const aboutSingleSubjectMatch = raw.match(
    /^(tell me about|describe|overview of|розкажи про|опиши)\s+(.+)$/i,
  );
  if (aboutSingleSubjectMatch) {
    const subject = aboutSingleSubjectMatch[2].trim();
    if (subject.split(/\s+/).length <= 3 && !looksLikePersonSubject(subject)) {
      return 'wide';
    }
  }

  const isAboutSomething =
    /\b(tell me about|describe|overview of|what are)\b/i.test(q) ||
    /\b(розкажи|опиши|що таке|що це)\b/i.test(q);

  const hasNonPersonSubject =
    /\b(company|компан|organization|product|tool|department|відділ|команд|team|process|процес|academy|академі|platform|system|системи|software)\b/i.test(q);

  if (isAboutSomething && hasNonPersonSubject) return 'wide';

  const tokens = q.split(/\s+/).filter(t => t.length > 0);
  const stopWords = new Set(['what','is','are','who','how','tell','me','about','the','a','an']);
  const meaningfulTokens = tokens.filter(t => !stopWords.has(t));
  if (
    meaningfulTokens.length === 1 &&
    /^[a-z]/.test(meaningfulTokens[0]) &&
    ['onix', 'company', 'product', 'tool', 'department', 'academy'].includes(meaningfulTokens[0])
  ) {
    return 'wide';
  }

  return null;
}

export class QueryClassifier {
  constructor(private readonly chatLlm: IChatLlmPort) {}
  async classify(query: string): Promise<QueryClassification> {

    const preGuard = preGuardClassify(query);
    if (preGuard !== null) {
      return this.build(preGuard, 0.9);
    }

    const prompt = `You are a query classifier for a Ukrainian corporate knowledge base RAG system.
Classify the query into EXACTLY ONE type. Reply ONLY with valid JSON — no markdown, no commentary.

TYPES:

  "entity"  — lookup of a SPECIFIC NAMED HUMAN PERSON only.
              Use ONLY when the subject is clearly an individual human being (first name, surname, nickname).
              Examples: "Хто такий Іван Петров?", "Find Olena Kovalenko", "Чеча",
                        "Розкажи про Дениса Шереметова", "що відомо про Марію Іваненко"

              ❌ NEVER "entity" for: company names, product names, tool names, department names,
                 brand names, or any non-human subject — even if they look like proper nouns.
              ❌ NOT entity: "розкажи про node департамент", "що робить HR відділ",
                             "why name company onix", "що таке onix", "tell me about onix",
                             "why is it called onix", "what does onix mean"

  "factual" — expects ONE short answer: a link, date, number, yes/no, policy rule.
              Also use for: questions about company name origin, founding date, brand meaning.
              Examples: "Який стек у backend?", "Дай посилання на hrm", "Коли salary review?",
                        "Скільки днів відпустки?", "Чи є sick leave?", "Як підключитись до wifi?",
                        "Коли заснована компанія?", "Як оплатити коворкінг з фоп?",
                        "А як тепер аппрувиться лікарняний?",
                        "why name company onix?", "what does the name onix mean?",
                        "when was onix founded?", "why is the company called onix?",
                        "what is vacation policy on company?"

  "wide"    — comprehensive overview, listing, procedural, or comparative.
              Use for DEPARTMENT / TEAM / TOOL / PROCESS / COMPANY overviews, and step-by-step guides.
              Examples: "Розкажи про node департамент", "Що робить QA команда?",
                        "Як оформити відпустку?", "Який lifecycle задачі?",
                        "Як можна збільшити зарплату?", "Чи можна працювати з іншої країни?",
                        "Перелічи всіх розробників", "Які команди є в компанії?",
                        "Розкажи про HR відділ", "Що таке onix academy?",
                        "tell me about onix company", "describe the history of onix"

Query: "${query}"

JSON: {"type": "entity" | "factual" | "wide", "confidence": 0.0-1.0}`;

    try {
      const raw = await this.chatLlm.complete(prompt, {
        temperature: 0,
        maxTokens:   60,
        topK:        1,
      });

      const match = raw.replace(/```(?:json)?/g, '').trim().match(/\{[\s\S]*?\}/);
      if (!match) return this.default();

      const parsed = JSON.parse(match[0]) as { type: QueryType; confidence: number };
      if (!PROFILE_BY_TYPE[parsed.type]) return this.default();

      const isLinkQuery = /посилання|лінк[аи]|сайт[іу]?\b|url\b|link\b/i.test(query);
      if (isLinkQuery && parsed.type === 'factual') {
        return this.build('factual', parsed.confidence, {
          ...PROFILE_BY_TYPE.factual,
          searchMode: 'entity',
        });
      }

      return this.build(parsed.type, Math.min(1, Math.max(0, parsed.confidence ?? 0.7)));
    } catch {
      return this.default();
    }
  }

  private build(type: QueryType, confidence: number, params?: FineTuningParams): QueryClassification {
    return { type, confidence, params: params ?? PROFILE_BY_TYPE[type] };
  }

  private default(): QueryClassification {
    return this.build('factual', 0.5);
  }
}