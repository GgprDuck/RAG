import { Body, Controller, Get, Inject, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { CommandBusPort } from 'src/rag/shared/application/ports/command-bus.port';
import { ApiResponse } from '../api-response/api-response';
import { Meta } from '../api-response/meta';
import { ApiKeyGuard } from '../guards/api-key.guard';
import { CreateFeedbackDto, UpdateFeedbackStatusDto } from '../dto/feedback.dto';
import {
  CreateFeedbackCommand,
  ListPendingFeedbackQuery,
  UpdateFeedbackStatusCommand,
} from 'src/rag/application/commands/feedback.commands';
import { FeedbackRecord } from 'src/rag/domain/ports/answer-feedback.repository.port';

@Controller('rag/feedback')
@UseGuards(ApiKeyGuard)
export class FeedbackController {
  constructor(
    @Inject('CommandBus') private readonly commandBus: CommandBusPort,
  ) {}

  @Post()
  async create(@Body() dto: CreateFeedbackDto): Promise<ApiResponse<FeedbackRecord>> {
    const created = await this.commandBus.execute<FeedbackRecord>(
      new CreateFeedbackCommand(
        dto.sessionId,
        dto.feedbackType,
        dto.answerId,
        dto.score,
        dto.correctionText,
        dto.comment,
      ),
    );
    return ApiResponse.success(created, new Meta({ message: 'Feedback captured' }));
  }

  @Get('pending')
  async listPending(@Query('limit') limit?: string): Promise<ApiResponse<FeedbackRecord[]>> {
    const pending = await this.commandBus.execute<FeedbackRecord[]>(
      new ListPendingFeedbackQuery(limit ? parseInt(limit, 10) : undefined),
    );
    return ApiResponse.success(pending, new Meta({ message: 'Pending feedback', count: pending.length }));
  }

  @Patch(':id/status')
  async updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateFeedbackStatusDto,
  ): Promise<ApiResponse<null>> {
    await this.commandBus.execute(new UpdateFeedbackStatusCommand(id, dto.status));
    return ApiResponse.success(null, new Meta({ message: 'Feedback status updated' }));
  }
}
