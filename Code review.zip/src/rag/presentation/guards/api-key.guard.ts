import { CanActivate, ExecutionContext, Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { RAG_CONFIG, TRagConfig } from 'src/rag/infrastructure/config/rag-config';
import { LoggerPort } from 'src/rag/shared/application/ports/logger.port';

@Injectable()
export class ApiKeyGuard implements CanActivate {
  constructor(
    private readonly configService: ConfigService,
    @Inject('LoggerPort') private readonly logger: LoggerPort,
  ) {}

  canActivate(context: ExecutionContext): boolean {
    const ragConfig = this.configService.get<TRagConfig>(RAG_CONFIG);
    const expectedApiKey = ragConfig?.apiKey?.trim();

    // Backward-compatible local development mode.
    if (!expectedApiKey) return true;

    const request = context.switchToHttp().getRequest<{ headers: Record<string, string | undefined> }>();
    const receivedApiKey = request.headers['x-api-key'] ?? request.headers.authorization;
    const normalizedReceived = (receivedApiKey ?? '').replace(/^Bearer\s+/i, '').trim();

    if (normalizedReceived !== expectedApiKey) {
      this.logger.warn('Unauthorized API request rejected by ApiKeyGuard');
      throw new UnauthorizedException('Invalid API key');
    }

    return true;
  }
}
