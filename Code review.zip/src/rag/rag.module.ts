import { Module, OnModuleInit, Inject } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ragConfig } from './infrastructure/config/rag-config';
import { OllamaModule } from './infrastructure/ollama/ollama.module';
import { S3Module } from './infrastructure/s3/s3.module';
import { S3StorageService } from './infrastructure/s3/s3.storage.service';
import { QdrantModule } from './infrastructure/qdrant/qdrant.module';
import { PrismaModule } from './infrastructure/prisma/prisma.module';
import { Neo4jModule } from './infrastructure/neo4j/neo4j.module';
import { RedisModule } from './infrastructure/redis/redis.module';
import { QdrantTextDocumentRepository } from './infrastructure/qdrant/repositories/qdrant-text-document.repository';
import { QdrantImageDocumentRepository } from './infrastructure/qdrant/repositories/qdrant-image-document.repository';
import { TextRagService } from './application/services/text-rag.service';
import { ImageRagService } from './application/services/image-rag.service';
import { RagCommandBusModule } from './shared/infrastructure/command-bus.module';
import { CommandBusPort } from './shared/application/ports/command-bus.port';
import { AskQuestionHandler } from './application/handlers/ask-question.handler';
import { AskQuestionStreamHandler } from './application/handlers/ask-question-stream.handler';
import { UploadKnowledgeHandler } from './application/handlers/upload-knowledge.handler';
import { DeleteDocumentHandler } from './application/handlers/delete-document.handler';
import { ProcessImagesHandler } from './application/handlers/process-images.handler';
import { DeleteImageHandler } from './application/handlers/delete-image.handler';
import { UploadFolderHandler } from './application/handlers/upload-folder.handler';
import {
  GetAllDocumentsHandler,
  GetAllImagesHandler,
  GetImagesByKeywordHandler,
  RetrieveDocumentsHandler,
} from './application/queries/rag-query.handlers';
import { AskQuestionCommand } from './application/commands/ask-question.command';
import { AskQuestionStreamCommand } from './application/commands/ask-question-stream.command';
import { UploadKnowledgeCommand } from './application/commands/upload-knowledge.command';
import { DeleteDocumentCommand } from './application/commands/delete-document.command';
import { ProcessImagesCommand } from './application/commands/process-images.command';
import { DeleteImageCommand } from './application/commands/delete-image.command';
import { UploadFolderCommand } from './application/commands/upload-folder.command';
import {
  GetAllDocumentsQuery,
  GetAllImagesQuery,
  GetImagesByKeywordQuery,
  RetrieveDocumentsQuery,
} from './application/queries/rag.queries';
import { RagDocumentsController } from './presentation/controllers/rag-documents.controller';
import { RagImagesController } from './presentation/controllers/image.controller';
import { LangChainChatAdapter } from './infrastructure/langchain/langchain-chat.adapter';
import { LangChainEmbeddingAdapter } from './infrastructure/langchain/langchain-embedding.adapter';
import { LangChainRetrieverAdapter } from './infrastructure/langchain/langchain-retriever.adapter';
import { ConfidenceService } from './application/services/confidence.service';
import { LinkService } from './application/services/link.service';
import { ChatController } from './presentation/controllers/chat.controller';
import { KnowledgeLinkPrismaRepository } from './domain/repositories/knowledge-link-prisma.repository';
import { LinksController } from './presentation/controllers/link.controller';
import { ExtractLinksHandler } from './application/handlers/extract-links.handler';
import { IndexLinksCommand } from './application/commands/extract-links.command';
import { CacheModule } from './infrastructure/redis/cache.module';
import { RagSettingsAdapter } from './infrastructure/config/rag-settings.adapter';
import { StructuredLoggerAdapter } from './shared/application/ports/structured.logger.adapter';
import { RoutingChatAdapter } from './infrastructure/langchain/routing-chat.adapter';
import { OllamaChatAdapter } from './infrastructure/ollama/ollama-chat.adapter';
import {
  ClearAllChatsCommand,
  DeleteChatCommand,
  GetChatQuery,
  ListChatsQuery,
} from './application/commands/chat-session.commands';
import {
  ClearAllChatsHandler,
  DeleteChatHandler,
  GetChatHandler,
  ListChatsHandler,
} from './application/handlers/chat-session.handlers';
import {
  DeleteLinksBySourceFileCommand,
  GetAllLinksQuery,
  IndexLinksFilesCommand,
  QueryLinksQuery,
  SearchLinksQuery,
} from './application/commands/link.commands';
import {
  DeleteLinksBySourceFileHandler,
  GetAllLinksHandler,
  IndexLinksFilesHandler,
  QueryLinksHandler,
  SearchLinksHandler,
} from './application/handlers/link.handlers';
import { ApiKeyGuard } from './presentation/guards/api-key.guard';
import {
  CreateFeedbackCommand,
  ListPendingFeedbackQuery,
  UpdateFeedbackStatusCommand,
} from './application/commands/feedback.commands';
import {
  CreateFeedbackHandler,
  ListPendingFeedbackHandler,
  UpdateFeedbackStatusHandler,
} from './application/handlers/feedback.handlers';
import { FeedbackController } from './presentation/controllers/feedback.controller';

@Module({
  imports: [
    ConfigModule.forFeature(ragConfig),
    RedisModule,
    OllamaModule,
    S3Module,
    QdrantModule,
    PrismaModule,
    Neo4jModule,
    RagCommandBusModule,
    CacheModule,
  ],
  providers: [
    RagSettingsAdapter,
    LangChainRetrieverAdapter,
    { provide: 'IRagSettingsPort',          useExisting: RagSettingsAdapter },
    { provide: 'IRagContextFormattingPort', useExisting: LangChainRetrieverAdapter },
    { provide: 'LoggerPort',               useClass: StructuredLoggerAdapter },
    { provide: 'IEmbeddingPort',           useClass: LangChainEmbeddingAdapter },
    { provide: 'PrimaryChatLlmPort',       useClass: LangChainChatAdapter },
    { provide: 'SecondaryChatLlmPort',     useClass: OllamaChatAdapter },
    { provide: 'IChatLlmPort',             useClass: RoutingChatAdapter },
    { provide: 'ITextDocumentRepository',  useExisting: QdrantTextDocumentRepository },
    { provide: 'IImageDocumentRepository', useExisting: QdrantImageDocumentRepository },
    { provide: 'IStoragePort',             useExisting: S3StorageService },
    { provide: 'TextRagPort',              useClass: TextRagService },
    { provide: 'ImageRagPort',             useClass: ImageRagService },
    { provide: 'IConfidencePort',          useExisting: ConfidenceService },
    { provide: 'IKnowledgeLinkRepository', useExisting: KnowledgeLinkPrismaRepository },
    KnowledgeLinkPrismaRepository,
    LinkService,
    ConfidenceService,
    AskQuestionHandler,
    AskQuestionStreamHandler,
    UploadKnowledgeHandler,
    DeleteDocumentHandler,
    ProcessImagesHandler,
    DeleteImageHandler,
    UploadFolderHandler,
    GetAllDocumentsHandler,
    GetAllImagesHandler,
    GetImagesByKeywordHandler,
    RetrieveDocumentsHandler,
    ExtractLinksHandler,
    ApiKeyGuard,
    ListChatsHandler,
    GetChatHandler,
    DeleteChatHandler,
    ClearAllChatsHandler,
    GetAllLinksHandler,
    SearchLinksHandler,
    QueryLinksHandler,
    DeleteLinksBySourceFileHandler,
    IndexLinksFilesHandler,
    CreateFeedbackHandler,
    ListPendingFeedbackHandler,
    UpdateFeedbackStatusHandler,
  ],
  controllers: [
    RagDocumentsController,
    RagImagesController,
    ChatController,
    LinksController,
    FeedbackController,
  ],
})
export class RagModule implements OnModuleInit {
  constructor(
    @Inject('CommandBus') private readonly bus: CommandBusPort,
    private readonly askQuestion: AskQuestionHandler,
    private readonly askQuestionStream: AskQuestionStreamHandler,
    private readonly uploadKnowledge: UploadKnowledgeHandler,
    private readonly deleteDocument: DeleteDocumentHandler,
    private readonly processImages: ProcessImagesHandler,
    private readonly deleteImage: DeleteImageHandler,
    private readonly uploadFolder: UploadFolderHandler,
    private readonly getAllDocuments: GetAllDocumentsHandler,
    private readonly getAllImages: GetAllImagesHandler,
    private readonly getImagesByKeyword: GetImagesByKeywordHandler,
    private readonly retrieveDocuments: RetrieveDocumentsHandler,
    private readonly extractLinks: ExtractLinksHandler,
    private readonly listChats: ListChatsHandler,
    private readonly getChat: GetChatHandler,
    private readonly deleteChatSession: DeleteChatHandler,
    private readonly clearAllChats: ClearAllChatsHandler,
    private readonly getAllLinks: GetAllLinksHandler,
    private readonly searchLinks: SearchLinksHandler,
    private readonly queryLinks: QueryLinksHandler,
    private readonly deleteLinksBySourceFile: DeleteLinksBySourceFileHandler,
    private readonly indexLinksFiles: IndexLinksFilesHandler,
    private readonly createFeedback: CreateFeedbackHandler,
    private readonly listPendingFeedback: ListPendingFeedbackHandler,
    private readonly updateFeedbackStatus: UpdateFeedbackStatusHandler,
  ) {}

  onModuleInit(): void {
    this.bus.register(AskQuestionCommand,       this.askQuestion);
    this.bus.register(AskQuestionStreamCommand, this.askQuestionStream);
    this.bus.register(UploadKnowledgeCommand,  this.uploadKnowledge);
    this.bus.register(DeleteDocumentCommand,   this.deleteDocument);
    this.bus.register(ProcessImagesCommand,    this.processImages);
    this.bus.register(DeleteImageCommand,      this.deleteImage);
    this.bus.register(UploadFolderCommand,     this.uploadFolder);
    this.bus.register(GetAllDocumentsQuery,    this.getAllDocuments);
    this.bus.register(GetAllImagesQuery,       this.getAllImages);
    this.bus.register(GetImagesByKeywordQuery, this.getImagesByKeyword);
    this.bus.register(RetrieveDocumentsQuery,  this.retrieveDocuments);
    this.bus.register(IndexLinksCommand,       this.extractLinks);
    this.bus.register(ListChatsQuery,          this.listChats);
    this.bus.register(GetChatQuery,            this.getChat);
    this.bus.register(DeleteChatCommand,       this.deleteChatSession);
    this.bus.register(ClearAllChatsCommand,    this.clearAllChats);
    this.bus.register(GetAllLinksQuery,        this.getAllLinks);
    this.bus.register(SearchLinksQuery,        this.searchLinks);
    this.bus.register(QueryLinksQuery,         this.queryLinks);
    this.bus.register(DeleteLinksBySourceFileCommand, this.deleteLinksBySourceFile);
    this.bus.register(IndexLinksFilesCommand,  this.indexLinksFiles);
    this.bus.register(CreateFeedbackCommand, this.createFeedback);
    this.bus.register(ListPendingFeedbackQuery, this.listPendingFeedback);
    this.bus.register(UpdateFeedbackStatusCommand, this.updateFeedbackStatus);
  }
}