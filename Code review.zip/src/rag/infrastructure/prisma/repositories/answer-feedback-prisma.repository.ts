import { Injectable } from '@nestjs/common';
import {
  CreateFeedbackInput,
  FeedbackRecord,
  FeedbackStatus,
  IAnswerFeedbackRepository,
} from 'src/rag/domain/ports/answer-feedback.repository.port';
import { PrismaService } from '../prisma.service';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class AnswerFeedbackPrismaRepository implements IAnswerFeedbackRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(input: CreateFeedbackInput): Promise<FeedbackRecord> {
    const created = await (this.prisma as any).answerFeedback.create({
      data: {
        id: uuidv4(),
        sessionId: input.sessionId,
        answerId: input.answerId,
        feedbackType: input.feedbackType,
        status: 'pending',
        score: input.score,
        correctionText: input.correctionText,
        comment: input.comment,
      },
    });
    return created;
  }

  async listPending(limit = 100): Promise<FeedbackRecord[]> {
    return (this.prisma as any).answerFeedback.findMany({
      where: { status: 'pending' },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
  }

  async updateStatus(id: string, status: FeedbackStatus): Promise<void> {
    await (this.prisma as any).answerFeedback.update({
      where: { id },
      data: { status },
    });
  }
}
